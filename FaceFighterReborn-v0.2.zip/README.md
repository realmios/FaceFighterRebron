# Face Fighter Reborn v0.2

This is the v0.2 continuation of the original Face Fighter Web v0.1 prototype.

## Changes
- Animated placeholder fighters
- JAB / HOOK / KICK / BLOCK / FURY
- Damage, blocking, stun and knockback
- Fury meter logic
- Enemy AI
- 60-second rounds
- Touch controls for iPhone Safari

The project is intentionally asset-free at this stage so original Face Fighter resources can be integrated separately.
