const ATTACKS={
 jab:{damage:7,range:145,fury:8,stun:.10,knock:80},
 hook:{damage:11,range:150,fury:12,stun:.16,knock:120},
 kick:{damage:16,range:175,fury:16,stun:.22,knock:160},
 fury:{damage:30,range:205,fury:0,stun:.35,knock:240}
};
function distance(a,b){return Math.abs(a.x-b.x)}
function resolveAttack(attacker,defender,type){
  const a=ATTACKS[type]; if(!a)return;
  if(distance(attacker,defender)>a.range)return false;
  let damage=a.damage;
  if(defender.blocking) damage=Math.ceil(damage*.25);
  defender.hp=Math.max(0,defender.hp-damage);
  defender.fury=Math.min(100,defender.fury+a.fury);
  attacker.fury=Math.min(100,attacker.fury+Math.ceil(a.fury*.65));
  defender.stun=a.stun*(defender.blocking?.35:1);
  defender.vx=attacker.side*a.knock*(defender.blocking?.25:1);
  defender.flash=.12;
  return true;
}