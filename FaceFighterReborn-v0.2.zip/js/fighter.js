class Fighter {
  constructor(name,x,side){
    this.name=name; this.x=x; this.baseX=x; this.side=side;
    this.y=385; this.vx=0; this.hp=100; this.fury=0;
    this.state="idle"; this.stateTime=0; this.attackHit=false;
    this.blocking=false; this.flash=0; this.stun=0;
  }
  canAct(){ return this.stun<=0 && this.state==="idle"; }
  start(state){
    if(!this.canAct()) return false;
    this.state=state; this.stateTime=0; this.attackHit=false; this.blocking=state==="block"; return true;
  }
  update(dt){
    this.stateTime+=dt;
    this.x+=this.vx*dt; this.vx*=Math.pow(.001,dt);
    this.stun=Math.max(0,this.stun-dt); this.flash=Math.max(0,this.flash-dt);
    const duration={jab:.24,hook:.38,kick:.52,fury:.9,block:.12,idle:.01}[this.state]||.2;
    if(this.state!=="idle" && this.stateTime>=duration){this.state="idle";this.stateTime=0;this.blocking=false}
  }
  draw(ctx){
    ctx.save(); ctx.translate(this.x,this.y); ctx.scale(this.side,1);
    if(this.flash>0) ctx.globalAlpha=.55;
    const attack=this.state;
    let lean=0, arm=0, leg=0;
    if(attack==="jab") arm=42*Math.min(1,this.stateTime/.08)*(this.stateTime<.16?1:0);
    if(attack==="hook") arm=34*Math.sin(Math.min(1,this.stateTime/.38)*Math.PI);
    if(attack==="kick") leg=40*Math.sin(Math.min(1,this.stateTime/.52)*Math.PI);
    if(attack==="fury"){arm=55*Math.sin(this.stateTime/.9*Math.PI);lean=8}
    if(attack==="block") arm=-18;
    ctx.rotate(lean*Math.PI/180);
    ctx.strokeStyle="#222";ctx.lineWidth=18;ctx.lineCap="round";
    ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,72);ctx.stroke();
    ctx.lineWidth=15;
    ctx.beginPath();ctx.moveTo(0,72);ctx.lineTo(-22,130);ctx.moveTo(0,72);ctx.lineTo(24,130);ctx.stroke();
    ctx.lineWidth=14;
    ctx.beginPath();ctx.moveTo(0,15);ctx.lineTo(-38,42);ctx.moveTo(0,15);ctx.lineTo(38+(arm),42);ctx.stroke();
    ctx.fillStyle=this.side>0?"#ffd2b8":"#e9b59b";ctx.beginPath();ctx.arc(0,-25,28,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#333";ctx.beginPath();ctx.arc(0,-37,25,Math.PI,Math.PI*2);ctx.fill();
    ctx.restore();
  }
}