const canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");
const p=new Fighter("PLAYER",280,1), e=new Fighter("ENEMY",680,-1);
let running=true,timeLeft=60,last=performance.now(),enemyThink=0;
const $=id=>document.getElementById(id);
function act(type){
  if(!running)return;
  if(type==="block"){p.start("block");return}
  if(type==="fury" && p.fury<100)return;
  if(p.start(type)){
    if(type==="fury")p.fury=0;
    setTimeout(()=>resolveAttack(p,e,type),type==="jab"?80:type==="hook"?120:type==="kick"?170:220);
  }
}
document.querySelectorAll("[data-action]").forEach(b=>{
  b.addEventListener("pointerdown",ev=>{ev.preventDefault();act(b.dataset.action)})
});
$("restart").onclick=()=>location.reload();
function ai(dt){
  enemyThink-=dt;if(enemyThink>0)return;
  enemyThink=.35+Math.random()*.65;
  const d=distance(e,p);
  if(d>175){e.vx=-e.side*120;return}
  const r=Math.random();
  if(r<.18)e.start("block");
  else if(r<.48)e.start("jab");
  else if(r<.72)e.start("hook");
  else e.start("kick");
  const type=e.state;
  setTimeout(()=>{if(type==="fury"&&e.fury<100)return;resolveAttack(e,p,type);if(type==="fury")e.fury=0},type==="jab"?80:type==="hook"?120:type==="kick"?170:220);
}
function drawArena(){
  ctx.clearRect(0,0,960,540);
  ctx.fillStyle="#b8d7ef";ctx.fillRect(0,0,960,335);
  ctx.fillStyle="#7fbd67";ctx.fillRect(0,335,960,205);
  ctx.fillStyle="#6b9e54";ctx.fillRect(0,455,960,85);
  ctx.strokeStyle="#ffffff55";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(80,455);ctx.lineTo(880,455);ctx.stroke();
  p.draw(ctx);e.draw(ctx);
}
function loop(now){
  const dt=Math.min(.033,(now-last)/1000);last=now;
  if(running){
    timeLeft=Math.max(0,timeLeft-dt);
    p.update(dt);e.update(dt);ai(dt);
    p.x=Math.max(90,Math.min(870,p.x));e.x=Math.max(90,Math.min(870,e.x));
    if(p.hp<=0||e.hp<=0||timeLeft<=0){
      running=false;$("restart").style.display="block";
      $("message").textContent=p.hp===e.hp?"TIME!":p.hp>e.hp?"YOU WIN":"YOU LOSE";
    }
  }
  $("playerBar").style.width=p.hp+"%";$("enemyBar").style.width=e.hp+"%";$("timer").textContent=Math.ceil(timeLeft);
  drawArena();requestAnimationFrame(loop);
}
requestAnimationFrame(loop);