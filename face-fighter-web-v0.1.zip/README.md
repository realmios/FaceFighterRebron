# Face Fighter Web Combat v0.1

Safari-friendly Canvas prototype. Includes touch controls, health, timer, jab/hook/kick, block, fury and simple enemy AI.

Replace files in `assets/` later with extracted game resources.
Upload the whole folder to GitHub Pages to test on iPhone.
